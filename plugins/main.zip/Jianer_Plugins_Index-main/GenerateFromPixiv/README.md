## GenerateFromPixiv QQ机器人插件

一个从Pixiv生成图片的QQ机器人插件

### 功能

- 通过lolicon.app API获取Pixiv图片
- 支持多标签搜索(用&分隔)
- 自动过滤R-18内容
- 18秒个人冷却时间限制

### 使用方法

在QQ群中发送：
```
生图 Pixiv [标签1]&[标签2]...
```

例如：
```
生图 Pixiv 原神&甘雨
```
